# Example Package

This package reads apex log file and provide required information.

You can also refer below link:
https://github.com/ganeshkp/apex-read